
Use AWSD to move and mouse to rotate FPS camera
Press ESC to quit

Feature:
Skeletal Animation
Skinned Instancing (Instancing with multiple animation applied)
Standart Diffuse+Specular+Ambient Light
Normal Map
Space mode and FPS mode camera support
Flexible shader management
Compute shader support

Shadow Map (Not complete)
Clustered Rendering/Forward+ (Not complete)
Adaptive Transparency (Not complete)

lib dependent:
Assimp (as Model loader)
Stb-master (as Texture loader)

API dependent:
DirectX 11